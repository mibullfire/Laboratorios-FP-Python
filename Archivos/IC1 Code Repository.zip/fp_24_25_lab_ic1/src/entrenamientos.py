from collections import namedtuple
from datetime import datetime
from csv import reader

Entrenamiento = namedtuple('Entreno', 'tipo, fechahora, ubicacion, duracion, calorias, distancia, frecuencia, compartido')

def lee_entrenamientos(ruta_fichero:str)->list[Entrenamiento]:
    result = []
    with open(ruta_fichero, encoding='utf-8') as fichero:
        lector = reader(fichero)
        next(lector)
        for subcadenas in lector:
            tipo = subcadenas[0]
            fechahora = datetime.strptime(subcadenas[1], '%d/%m/%Y %H:%M')
            ubicacion = subcadenas[2]
            duracion = int(subcadenas[3])
            calorias = int(subcadenas[4])
            distancia = float(subcadenas[5])
            frecuencia = int(subcadenas[6])
            compartido = subcadenas[7].strip() == 'S'
            entreno = Entrenamiento(tipo, fechahora, ubicacion, duracion, calorias, distancia, frecuencia, compartido)
            result.append(entreno)
    return result