def check_examen(nota):
    result = nota
    if nota == None:
        result = 0
    return result

def nota_teoria(primer_examen, segundo_examen):
    primero = check_examen(primer_examen)
    segundo = check_examen(segundo_examen)
    cuatrimestre = (primero + segundo) / 2
    return cuatrimestre

def nota_cuatrimestre(nota_teoria_1, nota_teoria_2, parcial):
    teoria = nota_teoria(nota_teoria_1, nota_teoria_2)
    examen_lab = check_examen(parcial)
    result = 0.2 * teoria + 0.8 * examen_lab
    if teoria < 4:
        result = 0
    return result

def nota_continua(teoricos, practicos):
    c1 = nota_cuatrimestre(teoricos[0], teoricos[1], practicos[0])
    c2 = nota_cuatrimestre(teoricos[2], teoricos[3], practicos[1])
    result = (c1 + c2)/2
    if c1<4 or c2<4:
        result = min(4, result)
    return result

