from matplotlib import pyplot as plt

from poblacion import filtra_por_pais, filtra_por_paises_y_anyo

def selecciona_item(datos: list[tuple[int,int]], indice:int):
    result = []
    for dato in datos:
        result.append(dato[indice])
    return result

###############################################################################################
def muestra_evolucion_poblacion(poblaciones, pais_o_codigo):
    """
    Genera una curva con la evolución de la población de un país. El país puede
    darse como su nombre completo o por su código.

    @param poblaciones: lista de tuplas con información de poblaciones
    @type poblaciones: list(RegistroPoblacion)
    @param pais_o_codigo: nombre o código del país del que se generará la gráfica
    @type pais_o_codigo: str
    """
    # TODO Complete la función para asignar los valores correctos
    #  a las variables titulo, lista_años y lista_habitantes
    titulo = "Evolución de la población en " + pais_o_codigo
    datos = filtra_por_pais(poblaciones, pais_o_codigo)
    lista_años = selecciona_item(datos, 0)
    lista_habitantes = selecciona_item(datos, 1)

    # Estas instrucciones dibujan la gráfica
    plt.title(titulo)
    plt.plot(lista_años, lista_habitantes)
    plt.show()


###############################################################################################

###############################################################################################
def muestra_comparativa_paises_anyo(poblaciones, año, paises):
    """
    Genera una gráfica de barras en la que se muestra la comparativa de
    la población de varios países en un año concreto

    @param poblaciones: lista de tuplas con información de poblaciones
    @type poblaciones: list(RegistroPoblacion)
    @param año: del que se generará la gráfica
    @type año: int
    @param paises: nombres de los países para los que se generará la gráfica
    @type paises: list(str)
    """
    # TODO Complete la función para asignar los valores correctos
    #  a las variables titulo, lista_paises y lista_habitantes
    titulo = "Poblaciones en anyo " + str(año)
    datos = filtra_por_paises_y_anyo(poblaciones, año, paises)
    lista_paises = selecciona_item(sorted(datos), 0)
    lista_habitantes = selecciona_item(sorted(datos), 1)

    # Estas instrucciones dibujan la gráfica
    plt.title(titulo)
    plt.bar(lista_paises, lista_habitantes)
    plt.show()