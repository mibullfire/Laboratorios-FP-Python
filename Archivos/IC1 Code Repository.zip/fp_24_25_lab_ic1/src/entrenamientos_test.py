from entrenamientos import lee_entrenamientos

def test_lee_entrenos():
    ruta_fichero = 'data/entrenos.csv'
    entrenos = lee_entrenamientos(ruta_fichero)
    
    print("Primeros tres registros:")
    for entreno in entrenos[:3]:
        print(entreno)
    
    print("\nÚltimos tres registros:")
    for entreno in entrenos[-3:]:
        print(entreno)

def main():
    test_lee_entrenos()


if __name__ == "__main__":
    main()