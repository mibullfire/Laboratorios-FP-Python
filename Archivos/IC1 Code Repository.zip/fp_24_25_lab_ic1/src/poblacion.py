# -*- coding: utf-8 -*-

""" 
Poblacion mundial
@author: Toñi Reina
REVISOR: José Antonio Troyano, Daniel Mateos, Mariano González, Fermín Cruz
ÚLTIMA MODIFICACIÓN: 10/10/2022
"""

import csv
from matplotlib import pyplot as plt
from collections import namedtuple

RegistroPoblacion = namedtuple("RegistroPoblacion", "pais, codigo, anyo, censo")

############################################################################################
def lee_poblaciones(ruta_fichero):
    """
    Lee el fichero de entrada y devuelve una lista de tuplas poblaciones

    @param fichero: nombre del fichero de entrada
    @type fichero: str

    @return: lista de tuplas con la información del fichero
    @rtype: RegistroPoblacion
    """
    poblaciones = []
    with open(ruta_fichero, encoding='utf-8') as f:
        lector = csv.reader(f)
        for linea in lector:
            pais = linea[0]
            codigo = linea[1]
            anyo = int(linea[2])
            censo = int(linea[3])
            registro = RegistroPoblacion(pais, codigo, anyo, censo)
            poblaciones.append(registro)
    return poblaciones


def calcula_paises(poblaciones):
    """
    Calcula la lista de países distintos presentes en una lista de de tuplas de tipo RegistroPoblacion.

    @param poblaciones: lista de tuplas con información de poblaciones
    @type poblaciones: list(RegistroPoblacion)

    @return: lista de paises, ordenada alfabéticamente, sin duplicados
    @rtype: list(str)
    """
    #paises_sin_repetir = {registro.pais for registro in poblaciones}
    paises_sin_repetir = set()
    for registro in poblaciones:
        paises_sin_repetir.add(registro.pais)
    return sorted(paises_sin_repetir)

def filtra_por_pais(poblaciones, nombre_o_codigo):
    """
    Devuelve el año y el censo de las tuplas correspondientes a un determinado pais

    @param poblaciones: lista de tuplas con información de poblaciones
    @type poblaciones: list(RegistroPoblacion)
    @param nombre_o_codigo: nombre o código del país del que se seleccionarán los registros
    @type nombre_o_codigo: str

    @return: lista de tuplas (año, censo) seleccionadas
    @rtype: list(tuple(int, int))
    """
    #result = [(registro.año, registro.censo) 
    #        for registro in poblaciones 
    #        if registro.pais == nombre_o_codigo or registro.codigo == nombre_o_codigo]
    result = []
    for registro in poblaciones:
        if registro.pais == nombre_o_codigo or registro.codigo == nombre_o_codigo:
            result.append((registro.anyo, registro.censo))
    return sorted(result)

##############################################################################################

##############################################################################################
def filtra_por_paises_y_anyo(poblaciones, anyo, paises):
    """
    Devuelve el país y el censo de las tuplas correspondientes a un conjunto de paises de un año concreto.

    @param poblaciones: lista de tuplas con información de poblaciones
    @type poblaciones: list(RegistroPoblacion)
    @param anyo: anyo del que se seleccionarán los registros
    @type anyo: int
    @param paises: conjunto de nombres de países de los que se seleccionarán los registros
    @type paises: set(str)

    @return: lista de tuplas (pais, censo) seleccionadas
    @rtype: list(tuple(str,int))
    """
    #result = [(registro.pais, registro.censo) 
    #               for registro in poblaciones 
    #               if registro.año == anyo and registro.pais in paises]
    result = []
    for registro in poblaciones:
        if registro.anyo == anyo and registro.pais in paises:
            result.append((registro.pais, registro.censo))
    return result

##############################################################################################


