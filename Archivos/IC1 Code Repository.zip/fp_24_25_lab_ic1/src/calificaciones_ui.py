def solicita_notas():
    nombre = input('Introduzca su nombre: ')
    examenes_teoricos, examenes_practicos = [], []
    for i in range(4):
        nota = float(input(f'Introduzca la nota del examen teórico {i + 1} (- si no se ha presentado): '))
        examenes_teoricos.append(nota)
    for i in range(2):
        nota = float(input(f'Introduzca la nota del examen práctico {i + 1} (- si no se ha presentado): '))
        examenes_practicos.append(nota)
    return nombre, tuple(examenes_practicos), tuple(examenes_teoricos)

def mostrar_notas(examenes_teoricos, examenes_practicos, nombre):
    print('Hola', nombre, '.')
    media_teorico_primer_cuatrimestre = (examenes_teoricos[0] + examenes_teoricos[1]) / 2
    media_teorico_segundo_cuatrimestre = (examenes_teoricos[2] + examenes_teoricos[3]) / 2
    media_practico_primer_cuatrimestre = examenes_practicos[0]
    media_practico_segundo_cuatrimestre = examenes_practicos[1]
    
    print('Tus notas del primer cuatrimestre son:')
    print(f'Teórico: {media_teorico_primer_cuatrimestre}')
    print(f'Práctico: {media_practico_primer_cuatrimestre}')
    
    print('Tus notas del segundo cuatrimestre son:')
    print(f'Teórico: {media_teorico_segundo_cuatrimestre}')
    print(f'Práctico: {media_practico_segundo_cuatrimestre}')
    
    nota_final_asignatura = (media_teorico_primer_cuatrimestre + media_teorico_segundo_cuatrimestre + media_practico_primer_cuatrimestre + media_practico_segundo_cuatrimestre) / 4
    print(f'Tu nota final de la asignatura es: {nota_final_asignatura}')
    return nota_final_asignatura

if __name__ == '__main__':
    nombre, practicos, teoricos = solicita_notas()
    mostrar_notas(teoricos, practicos, nombre)