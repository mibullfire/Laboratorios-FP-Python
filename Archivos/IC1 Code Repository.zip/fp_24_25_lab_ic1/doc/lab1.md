# Ejercicio de laboratorio: Piedra, Papel o Tijeras

**Autor**: Fermín Cruz

**Revisor**: Jorge García

**Fecha última modificación**: 19/09/2024

En este proyecto vamos a implementar el juego de "Piedra, Papel o Tijeras". Empezaremos implementando funciones para resolver cada uno de los pasos del juego, y después implementaremos la mecánica del juego haciendo uso de dichas funciones.

El juego consiste en elegir entre las opciones ``piedra``, ``papel`` o ``tijeras``. El adversario (el ordenador) elegirá también una de estas opciones. Ambos jugadores eligen sin saber lo que elegirá el contrario. Para determinar quién gana una ronda, se siguen estas reglas:

* La piedra gana a las tijeras.
* Las tijeras ganan al papel.
* El papel gana a la piedra.
* Si los dos jugadores escogen la misma opción, se produce un empate.

El juego se puede jugar al mejor de varias rondas, de manera que si el usuario gana una partida, se suma un punto; si gana el ordenador, se resta un punto; y si hay empate, se suma 0.

## Preparación del proyecto

Cree una carpeta ``src``, y dentro de esta un módulo ``piedra_papel_tijeras.py`` y un módulo ``piedra_papel_tijeras_test.py``.

### Ejercicio 1: Implementación de funciones

#### Apartado a

Añada al módulo ``piedra_papel_tijeras.py`` una función ``parsea_jugada_usuario`` como la mostrada a continuación:

```python
import random

def parsea_jugada_usuario(eleccion_usuario:int)->int:
    ''' 
    Comprueba que el usuario haya elegido 0,1 o 2 (piedra, papel o tijeras) y devuelve la elección. Si la elección no es válida, devuelve -1.     
    '''
    if eleccion_usuario not in [0,1,2]:
        # Valor no válido
        eleccion_usuario = -1
    return eleccion_usuario
```

En el módulo ``piedra_papel_tijeras_test.py``, añada el siguiente código:

```python
from piedra_papel_tijeras import *

print(parsea_jugada_usuario(0))
print(parsea_jugada_usuario(1))
print(parsea_jugada_usuario(2))
print(parsea_jugada_usuario(56))
print(parsea_jugada_usuario(-1000.0))
```

Ejecute el módulo ``piedra_papel_tijeras_test.py``. Debe observar por consola mensajes indicando la elección realizada por el usuario.

#### Apartado b

Con ayuda de su profesor, ejecute paso a paso el módulo ``piedra_papel_tijeras_test.py`` en modo depuración. Trate de entender detenidamente el flujo de ejecución.

#### Apartado c

Añada al módulo ``piedra_papel_tijeras.py`` el siguiente código:

```python
def get_jugada_ordenador()->int:
    ''' 
    Elige aleatoriamente entre piedra (0), papel(1) o tijeras(2) y devuelve la elección.     
    '''
    res = random.randint(0, 2)
    return res

def determina_ganador(jugada_usuario:int, jugada_ordenador:int)->int:
    ''' Determina el ganador del juego en base a la selección 
    realizada por el usuario y el ordenador. 
    0: empate, 1: gana usuario, -1: gana ordenador . '''
    if jugada_usuario == jugada_ordenador:
        resultado = 1
    elif jugada_usuario == 0 and jugada_ordenador == 2:
        resultado = 1
    elif jugada_usuario == 2 and jugada_ordenador == 1:
        resultado = 1
    elif jugada_usuario == 1 and jugada_ordenador == 0:
        resultado = 1
    else:
        resultado = -1
    
    return resultado

def jugar_una(eleccion_usuario:int)->tuple[int, int]:
    '''
    Función principal que ejecuta el juego de Piedra, Papel o Tijeras.
    '''
    eleccion_ordenador = get_jugada_ordenador()
    eleccion_usuario_1 = parsea_jugada_usuario(eleccion_usuario)    
    resultado = determina_ganador(eleccion_usuario_1, eleccion_ordenador)
    return eleccion_ordenador, resultado
```

En el módulo ``piedra_papel_tijeras_test.py``, sustituya el código completo por este otro:

```python
from piedra_papel_tijeras import *

OPCIONES = ["piedra", "papel", "tijeras"]
RESULTADO = ['Empate', 'Ganaste', 'Perdiste']

def jugar_partida()->tuple[int, int]:
    '''Función principal que ejecuta el juego de Piedra, Papel o Tijeras.'''
    print("¡Vamos a jugar una partida!")
    eleccion_jugador = input("Introduzca su elección (0: piedra, 1: papel, 2: tijeras): ")
    eleccion_jugador = int(eleccion_jugador)
    eleccion_ord, result = jugar_una(eleccion_jugador)
    return eleccion_ord, result

def main()->None:
    print("¡Bienvenido al juego de Piedra, Papel o Tijeras!")
    eleccion_ord, result = jugar_partida()
    print(f"El ordenador eligió: {OPCIONES[eleccion_ord]}")
    print(f"Resultado: {RESULTADO[result]}")
    #jugar_mejor_de_n(3)


if __name__ == "__main__":
    main()
```

Ejecute el módulo ``piedra_papel_tijeras_test.py``. El programa le solicitará que escoja entre piedra, papel o tijeras y ejecutará una partida. Escriba la opción que desee y pulse *Enter*. Haciendo uso del depurador, trata de localizar el error en la implementación de la función ``determina_ganador`` y corrígelo.

### Ejercicio 2

#### Apartado a

Haciendo uso de la ejecución en modo depuración, ¿serías capaz de ganarle siempre al ordenador?

#### Apartado b (avanzado)

Se quiere implementar una versión del juego a tres puntos. Es decir, se jugarán varias rondas del juego, de manera que el usuario sumará un punto por victoria o se restará un punto por derrota (si hay empate, no se suma nada). Finalmente, si la suma final es positiva, ganará el usuario, si es negativa, lo hará el ordenador y si hay empate, se informará de ello.

¿Serías capaz de implementar esta versión del juego en una función ``jugar_mejor_de_n``?
